﻿namespace PrimeNumFinderCS
{
    partial class PrimeNumFinder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.headerText = new System.Windows.Forms.Label();
            this.inputBox = new System.Windows.Forms.TextBox();
            this.primeButton = new System.Windows.Forms.Button();
            this.changeColor = new System.Windows.Forms.Button();
            this.outputBox = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // headerText
            // 
            this.headerText.AutoSize = true;
            this.headerText.Location = new System.Drawing.Point(12, 9);
            this.headerText.Name = "headerText";
            this.headerText.Size = new System.Drawing.Size(618, 32);
            this.headerText.TabIndex = 0;
            this.headerText.Text = "Find All Prime Numbers Less Than Or Equal To:";
            // 
            // inputBox
            // 
            this.inputBox.Location = new System.Drawing.Point(18, 53);
            this.inputBox.Name = "inputBox";
            this.inputBox.Size = new System.Drawing.Size(425, 38);
            this.inputBox.TabIndex = 1;
            // 
            // primeButton
            // 
            this.primeButton.Location = new System.Drawing.Point(18, 112);
            this.primeButton.Name = "primeButton";
            this.primeButton.Size = new System.Drawing.Size(190, 55);
            this.primeButton.TabIndex = 2;
            this.primeButton.Text = "Start";
            this.primeButton.UseVisualStyleBackColor = true;
            this.primeButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // changeColor
            // 
            this.changeColor.Location = new System.Drawing.Point(554, 112);
            this.changeColor.Name = "changeColor";
            this.changeColor.Size = new System.Drawing.Size(217, 55);
            this.changeColor.TabIndex = 3;
            this.changeColor.Text = "Toggle Color";
            this.changeColor.UseVisualStyleBackColor = true;
            this.changeColor.Click += new System.EventHandler(this.changeColor_Click);
            // 
            // outputBox
            // 
            this.outputBox.Location = new System.Drawing.Point(18, 196);
            this.outputBox.Name = "outputBox";
            this.outputBox.Size = new System.Drawing.Size(753, 544);
            this.outputBox.TabIndex = 4;
            this.outputBox.Text = "";
            // 
            // PrimeNumFinder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(783, 764);
            this.Controls.Add(this.outputBox);
            this.Controls.Add(this.changeColor);
            this.Controls.Add(this.primeButton);
            this.Controls.Add(this.inputBox);
            this.Controls.Add(this.headerText);
            this.Name = "PrimeNumFinder";
            this.Text = "Prime Number Finder";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label headerText;
        private System.Windows.Forms.TextBox inputBox;
        private System.Windows.Forms.Button primeButton;
        private System.Windows.Forms.Button changeColor;
        private System.Windows.Forms.RichTextBox outputBox;
    }
}

