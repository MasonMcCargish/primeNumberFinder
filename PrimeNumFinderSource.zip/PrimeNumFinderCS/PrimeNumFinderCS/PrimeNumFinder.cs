﻿// Mason McCargish
// masonmccargish@gmail.com

using System;
using System.Windows.Forms;
using System.Threading;

namespace PrimeNumFinderCS
{
    public partial class PrimeNumFinder : Form
    {
        // Holds background color options for randomizer
        string[] COLORS = { "Red", "Blue", "Yellow"};
        // Flag for when already generating prime numbers
        bool isGenPrimes = false;

        public PrimeNumFinder()
        {
            InitializeComponent();
        }

        // Handles button for showing prime numbers
        private void button1_Click(object sender, EventArgs e)
        {
            // Executes findPrimes function on another thread if input valid
            if (isValidNumber(this.inputBox.Text) && !isGenPrimes)
            {
                new Thread(findPrimes).Start();
                isGenPrimes = true;
            }
        }

        bool isValidNumber(string input)
        {
            return long.TryParse(input, out long i);
        }

        // Finds all prime numbers less than value in inputBox
        void findPrimes()
        {
            for (int num = 1; num <= int.Parse(this.inputBox.Text); ++num)
            {
                if (isPrime(num))
                {
                    output(num + ", ");
                }
            }
            isGenPrimes = false;
        }

        // Outputs a string to the output box with thread protection
        public void output(string value)
        {
            // Used to avoid possible condition that two threads read at the same time, causing one of their changes to be overwritten
            lock (this.outputBox)
            {
                if (InvokeRequired)
                {
                    this.BeginInvoke(new Action<string>(output), new object[] { value });
                    return;
                }
                outputBox.Text += value;
            }
        }

        // Checks if a given number is prime
        bool isPrime(int num)
        {
            for (int i = 2; i < num; ++i)
            {
                if (num % i == 0) return false;
            }
            return true;
        }

        // Changes background to random color, and sends color name to ouput
        private void changeColor_Click(object sender, EventArgs e)
        {
            Random rand = new Random();
            int num = rand.Next() % 3;

            string newColor = COLORS[num];
            this.outputBox.BackColor = System.Drawing.Color.FromName(newColor);
            output(COLORS[num] + ", ");
        }
    }
}
